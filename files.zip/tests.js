import {fill,tempFactor,nextSeq,cableCheck} from './calc.js';
const eq=(a,b,m='')=>{if(a!==b)throw new Error(`${m} expected ${b}, got ${a}`)};
const near=(a,b,tol,m='')=>{if(!(Math.abs(a-b)<=tol))throw new Error(`${m} expected ${b}±${tol}, got ${a}`)};
const B={ph:1,I:20,V:230,L:50,pf:.9,mx:3,mat:'Cu',ins:'PVC',meth:'B1',amb:30,g:1,isc:1,tt:.1};
const T='{PROJ}-{SYS}-{ZONE}-{SEQ}-{SUF}',M={PROJ:'PRJ',SYS:'FA',ZONE:'G',SEQ:'001',SUF:''};
export const tests=[
 ['fill: empty suffix drops trailing dash',()=>eq(fill(T,M),'PRJ-FA-G-001')],
 ['fill: with suffix',()=>eq(fill(T,{...M,SUF:'A'}),'PRJ-FA-G-001-A')],
 ['tempFactor: 30°C = 1',()=>eq(tempFactor('PVC',30),1)],
 ['tempFactor: interpolates 32.5°C',()=>near(tempFactor('PVC',32.5),.97,.001)],
 ['tempFactor: clamps below range',()=>eq(tempFactor('PVC',5),1.22)],
 ['nextSeq: max per base',()=>eq(nextSeq([{base:'A',seq:3},{base:'A',seq:7},{base:'B',seq:9}],'A'),7)],
 ['nextSeq: empty = 0',()=>eq(nextSeq([],'A'),0)],
 ['baseline: 20A/50m/230V → 6mm², In 20',()=>{const r=cableCheck(B);eq(r.pick.s,6);eq(r.In,20);eq(r.gov,'D')}],
 ['baseline: voltage drop 2.965%',()=>near(cableCheck(B).pick.dp,2.965,.01)],
 ['baseline: 4mm² fails drop (4.4%)',()=>{const r=cableCheck(B).all[2];eq(r.okD,false);near(r.dp,4.43,.02)}],
 ['3-phase drop = √3/2 of single-phase',()=>near(cableCheck({...B,ph:3}).all[5].dv/cableCheck(B).all[5].dv,Math.sqrt(3)/2,.001)],
 ['aluminium derates ×0.78',()=>near(cableCheck({...B,mat:'Al'}).all[2].iz,24*.78,.001)],
 ['ambient 40°C PVC ×0.87',()=>near(cableCheck({...B,amb:40}).all[2].iz,24*.87,.001)],
 ['3 grouped circuits ×0.7',()=>near(cableCheck({...B,g:3}).all[2].iz,24*.7,.001)],
 ['breaker: 20.1A → 25A',()=>eq(cableCheck({...B,I:20.1}).In,25)],
 ['breaker: 700A out of range',()=>{const r=cableCheck({...B,I:700});eq(r.In,undefined);eq(r.pick,undefined)}],
 ['no single cable ≤240mm² found',()=>{const r=cableCheck({...B,I:500,L:500});eq(r.In,500);eq(r.pick,undefined)}],
 ['short-circuit governs: 6kA/0.4s → 35mm²',()=>{const r=cableCheck({...B,isc:6,tt:.4});eq(r.pick.s,35);eq(r.gov,'S')}],
];
